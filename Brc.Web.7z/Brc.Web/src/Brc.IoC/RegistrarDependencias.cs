﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Brc.Aplicacao;
using Brc.Dados;
using Brc.Dados.Repositorios;
using Brc.Dominio;
using Brc.Dominio.Repositorios;
using Brc.Dominio.Servicos;

namespace Brc.IoC
{
    public static class RegistrarDependencias
    {
        public static void Registrar(IServiceCollection servicos, IConfiguration configuracao)
        {
            #region ExemploWeb-metadado
            
			
            servicos.AddScoped<IUnitOfWork, UnitOfWork>();
            servicos.AddScoped<ContextoExemploBrc>(contexto => new ContextoExemploBrc(configuracao.GetConnectionString("DefaultConnection")));

            servicos.AddScoped<IServicoUsuario, ServicoUsuario>();
            servicos.AddScoped<IRepositorioUsuario, RepositorioUsuario>();
            
            servicos.AddScoped<IRepositorioProfessor , RepositorioProfessor>();
            servicos.AddScoped<IServicoProfessor, ServicoProfessor>();

            servicos.AddScoped<IRepositorioAluno, RepositorioAluno>();
            servicos.AddScoped<IServicoAluno, ServicoAluno>();

            servicos.AddScoped<IServicoAutenticacao, ServicoAutenticacao>();
            servicos.AddScoped<IServicoCriptografia, ServicoCriptografia>();

            servicos.AddDbContext<ContextoExemploBrc>(options =>
                                                       options.UseSqlServer(configuracao.GetConnectionString("DefaultConnection")));
            #endregion
        }
    }
}
