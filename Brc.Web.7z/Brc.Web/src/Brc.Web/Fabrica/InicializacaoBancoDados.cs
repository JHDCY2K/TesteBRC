﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Brc.Dados;
using Brc.Dominio.Entidades;
using Brc.Dominio.Servicos;

namespace Brc.Web
{
    public static class InicializacaoBancoDados
    {
        public static void Inicializar(IServiceProvider serviceProvider)
        {
            ContextoExemploBrc contextoBrc = serviceProvider.GetService(typeof(ContextoExemploBrc)) as ContextoExemploBrc;
            IServicoCriptografia servicoCriptografia = serviceProvider.GetService(typeof(IServicoCriptografia)) as IServicoCriptografia;

            if (contextoBrc.Usuario.Any())
            {
                return;
            }

            var usuario = new Usuario()
            {
                Nome = "Administrator",
                Senha = servicoCriptografia.Gerar("123"),
                Login = "admin",
                Ativo = true,
                DataCriacao = DateTime.Now,
                CriadoPor = "Sistema",
                DataAlteracao = (DateTime?)null,
                AlteradoPor = null,
                UltimoLogin = (DateTime?)null
            };

            contextoBrc.Usuario.Add(usuario);

            contextoBrc.SaveChanges();

        }
    }
}
