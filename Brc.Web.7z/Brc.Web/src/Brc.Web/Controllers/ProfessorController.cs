﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Brc.Dtos;
using Brc.Dominio.Entidades;
using Brc.Dominio.Repositorios;
using Brc.Dominio.Servicos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Omu.ValueInjecter;

namespace Brc.Web.Controllers
{
    [Authorize]
    public class ProfessorController : Controller
    {

        private readonly IServicoProfessor servicoProfessor;
        private readonly IServicoAluno servicoAluno;
        private readonly IUnitOfWork unitOfWork;

        public ProfessorController(IServicoProfessor servicoProfessor, IServicoAluno servicoAluno, IUnitOfWork unitOfWork)
        {
            this.servicoProfessor = servicoProfessor ?? throw new ArgumentNullException(nameof(servicoProfessor));
            this.servicoAluno = servicoAluno ?? throw new ArgumentNullException(nameof(servicoAluno));
            this.unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }

        
        // GET: Professores
        public IActionResult Index()
        {
            var professores = servicoProfessor.ObterProfessores();
            List<ProfessorModel> professoresModel = TransformaProfessoresEmModel(professores);
            return View(professoresModel);
        }

        private static List<ProfessorModel> TransformaProfessoresEmModel(IEnumerable<Professor> professores)
        {
            List<ProfessorModel> professoresModel = new List<ProfessorModel>();
            foreach (var professor in professores)
            {
                ProfessorModel professorModel = TransformarProfessorEmModel(professor);
                professoresModel.Add(professorModel);
            }

            return professoresModel;
        }

        private static ProfessorModel TransformarProfessorEmModel(Professor professor)
        {
            ProfessorModel professorModel = new ProfessorModel();
            professorModel.InjectFrom(professor);
            return professorModel;
        }

        // GET: Professores/Details/5
        public IActionResult Details(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var professor = servicoProfessor.ObterPorId(id.Value);
            if (professor == null)
            {
                return NotFound();
            }
            ProfessorModel professorModel = TransformarProfessorEmModel(professor);

            return View(professorModel);
        }

        // GET: Professores/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Professores/Create        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Nome")] ProfessorModel professorModel)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Professor professor = new Professor();
                    professor.InjectFrom(professorModel);
                    servicoProfessor.Inserir(professor);
                    unitOfWork.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }
            }
            return View(professorModel);
        }

        // GET: Professores/Edit/5
        public IActionResult Edit(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var professor = servicoProfessor.ObterPorId(id.Value);
            if (professor == null)
            {
                return NotFound();
            }
            ProfessorModel professorModel = TransformarProfessorEmModel(professor);
            //professorModel.SenhaAnterior = professor.Senha;
            return View(professorModel);
        }

        // POST: Professores/Edit/5        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(long id, [Bind("Id,Nome")] ProfessorModel professorModel)
        {
            if (id != professorModel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    Professor professor = servicoProfessor.ObterPorId(professorModel.Id);
                    professor.InjectFrom(professorModel);

                    servicoProfessor.Atualizar(professor);
                    unitOfWork.SaveChanges();

                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }
            }
            return View(professorModel);
        }

        // GET: Professores/Delete/5
        public IActionResult Delete(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var professor = servicoProfessor.ObterPorId(id.Value);
            if (professor == null)
            {
                return NotFound();
            }
            ProfessorModel professorModel = TransformarProfessorEmModel(professor);

            return View(professorModel);
        }

        // POST: Professores/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(long id)
        {
            var professor = servicoProfessor.ObterPorId(id);
            servicoProfessor.Remover(professor);
            unitOfWork.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Lista()
        {
            var alunos = servicoAluno.ObterListaProfessor(1, 15, 17);
            List<AlunoModel> alunosModel = TransformaAlunosEmModel(alunos);
            return View(alunosModel);
        }

        private static List<AlunoModel> TransformaAlunosEmModel(IEnumerable<Aluno> alunos)
        {
            List<AlunoModel> alunosModel = new List<AlunoModel>();
            foreach (var aluno in alunos)
            {
                AlunoModel alunoModel = TransformarAlunoEmModel(aluno);
                alunosModel.Add(alunoModel);
            }

            return alunosModel;
        }

        private static AlunoModel TransformarAlunoEmModel(Aluno aluno)
        {
            AlunoModel alunoModel = new AlunoModel();
            alunoModel.InjectFrom(aluno);
            return alunoModel;
        }
    }
}
