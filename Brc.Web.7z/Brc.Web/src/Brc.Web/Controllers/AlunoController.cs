﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Brc.Dtos;
using Brc.Dominio.Entidades;
using Brc.Dominio.Repositorios;
using Brc.Dominio.Servicos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Omu.ValueInjecter;

namespace Brc.Web.Controllers
{
    [Authorize]
    public class AlunoController : Controller
    {

        private readonly IServicoAluno servicoAluno;
        private readonly IServicoProfessor servicoProfessor;
        private readonly IUnitOfWork unitOfWork;

        public AlunoController(IServicoAluno servicoAluno, IServicoProfessor servicoProfessor,  IUnitOfWork unitOfWork)
        {
            this.servicoAluno = servicoAluno ?? throw new ArgumentNullException(nameof(servicoAluno));
            this.servicoProfessor = servicoProfessor ?? throw new ArgumentNullException(nameof(servicoProfessor));
            this.unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }



        // GET: Alunos
        public IActionResult Index()
        {
            var alunos = servicoAluno.ObterAlunos();
            List<AlunoModel> alunosModel = TransformaAlunosEmModel(alunos);
            return View(alunosModel);
        }

        private static List<AlunoModel> TransformaAlunosEmModel(IEnumerable<Aluno> alunos)
        {
            List<AlunoModel> alunosModel = new List<AlunoModel>();
            foreach (var aluno in alunos)
            {
                AlunoModel alunoModel = TransformarAlunoEmModel(aluno);
                alunosModel.Add(alunoModel);
            }

            return alunosModel;
        }

        private static AlunoModel TransformarAlunoEmModel(Aluno aluno)
        {
            AlunoModel alunoModel = new AlunoModel();
            alunoModel.InjectFrom(aluno);
            return alunoModel;
        }

        // GET: Alunos/Details/5
        public IActionResult Details(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var aluno = servicoAluno.ObterPorId(id.Value);
            if (aluno == null)
            {
                return NotFound();
            }
            AlunoModel alunoModel = TransformarAlunoEmModel(aluno);

            return View(alunoModel);
        }

        // GET: Alunos/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Alunos/Create        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Nome,IdProfessor,DataNascimento")] AlunoModel alunoModel)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Aluno aluno = new Aluno();
                    aluno.InjectFrom(alunoModel);
                    // busca nome professor


                    var professor = servicoProfessor.ObterPorId(alunoModel.IdProfessor);
                    if (professor == null)
                        throw new Exception("Professor inválido");

                    aluno.NomeProfessor = professor.Nome;

                    servicoAluno.Inserir(aluno);
                    unitOfWork.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }
            }
            return View(alunoModel);
        }

        // GET: Alunos/Edit/5
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var aluno = servicoAluno.ObterPorId(id.Value);
            if (aluno == null)
            {
                return NotFound();
            }

            var professor = servicoProfessor.ObterPorId(aluno.IdProfessor);

            aluno.NomeProfessor = professor.Nome;

            AlunoModel alunoModel = TransformarAlunoEmModel(aluno);
            return View(alunoModel);
        }

        // POST: Alunos/Edit/5        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(long id, [Bind("Id,Nome,IdProfessor,DataNascimento")] AlunoModel alunoModel)
        {
            if (id != alunoModel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    Aluno aluno = servicoAluno.ObterPorId(alunoModel.Id);

                    var professor = servicoProfessor.ObterPorId(aluno.IdProfessor);

                    aluno.NomeProfessor = professor.Nome;
                    alunoModel.NomeProfessor = professor.Nome;
                    aluno.InjectFrom(alunoModel);

                    servicoAluno.Atualizar(aluno);
                    unitOfWork.SaveChanges();

                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", ex.Message);
                }
            }
            return View(alunoModel);
        }

        // GET: Alunos/Delete/5
        public IActionResult Delete(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var aluno = servicoAluno.ObterPorId(id.Value);
            if (aluno == null)
            {
                return NotFound();
            }
            AlunoModel alunoModel = TransformarAlunoEmModel(aluno);

            return View(alunoModel);
        }

        // POST: Alunos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(long id)
        {
            var aluno = servicoAluno.ObterPorId(id);
            servicoAluno.Remover(aluno);
            unitOfWork.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Lista()
        {
            var alunos = servicoAluno.ObterLista(16);
            List<AlunoModel> alunosModel = TransformaAlunosEmModel(alunos);
            return View(alunosModel);
        }

        
    }
}
