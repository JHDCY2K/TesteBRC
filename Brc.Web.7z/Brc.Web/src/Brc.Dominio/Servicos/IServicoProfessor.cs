﻿using Brc.Dominio.Entidades;
using System.Collections.Generic;

namespace Brc.Dominio.Servicos
{
    public interface IServicoProfessor
    {
        Professor ObterPorId(long id);
        IEnumerable<Professor> ObterProfessores();
        void Atualizar(Professor professor);
        void Remover(Professor professor);
        void Inserir(Professor professor);
    }
}
