﻿using Brc.Dominio.Entidades;
using System.Collections.Generic;

namespace Brc.Dominio.Servicos
{
    public interface IServicoAluno

    {
        Aluno ObterPorId(long id);
        IEnumerable<Aluno> ObterAlunos();
        IEnumerable<Aluno> ObterLista(int idade);

        IEnumerable<Aluno> ObterListaProfessor(int id, int ini, int fim);

        void Atualizar(Aluno professor);
        void Remover(Aluno professor);
        void Inserir(Aluno professor);
    }
}
