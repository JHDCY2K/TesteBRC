﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Brc.Dominio.Entidades
{
    public class Aluno : Entidade
    {
        public long Id { get; set; }
        public string Nome { get; set; }
        public long IdProfessor { get; set; }
        public string NomeProfessor { get; set; }
        public DateTime DataNascimento { get; set; }
    }
}
