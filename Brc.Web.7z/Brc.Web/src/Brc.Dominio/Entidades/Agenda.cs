﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Brc.Dominio.Entidades
{
    public class Agenda : Entidade
    {
        public long IdCliente { get; set; }
        public DateTime DataAgenda { get; set; }


    }
}
