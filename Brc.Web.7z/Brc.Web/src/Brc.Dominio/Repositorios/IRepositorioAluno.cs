﻿using Brc.Dominio.Entidades;
using Brc.Dominio.Repositorios;
using System.Collections.Generic;

namespace Brc.Dados.Repositorios
{
    public interface IRepositorioAluno : IRepositorio<Aluno>
    {
        Aluno ObterPorNome(string nome);

        IEnumerable<Aluno> ObterLista(int idade);

        IEnumerable<Aluno>  ObterListaProfessor (int id, int ini, int fim);
    }
}