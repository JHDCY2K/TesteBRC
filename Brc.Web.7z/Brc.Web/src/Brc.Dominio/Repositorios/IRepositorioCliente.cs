﻿using Brc.Dominio.Entidades;
using Brc.Dominio.Repositorios;

namespace Brc.Dados.Repositorios
{
    public interface IRepositorioCliente : IRepositorio<Cliente>
    {
        Cliente ObterPorCPF(string cnpj);
    }
}