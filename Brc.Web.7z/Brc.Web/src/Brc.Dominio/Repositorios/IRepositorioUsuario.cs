﻿using System.Linq;
using Brc.Dominio.Entidades;

namespace Brc.Dominio.Repositorios
{
    public interface IRepositorioUsuario: IRepositorio<Usuario>
    {
        Usuario ObterPorLogin(string login);
    }
}