﻿using Brc.Dominio.Entidades;
using Brc.Dominio.Repositorios;
using System;

namespace Brc.Dados.Repositorios
{
    public interface IRepositorioAgenda : IRepositorio<Agenda>
    {
        Agenda ValidarData(DateTime dataagenda);

        Agenda ObterAgendaPaciente(long idUsuario);

        Agenda ObterAgenda(long idUsuario);
    }
}