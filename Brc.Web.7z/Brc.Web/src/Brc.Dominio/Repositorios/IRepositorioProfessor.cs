﻿using Brc.Dominio.Entidades;
using Brc.Dominio.Repositorios;

namespace Brc.Dados.Repositorios
{
    public interface IRepositorioProfessor : IRepositorio<Professor>
    {
        Professor ObterPorNome(string cnpj);
    }
}