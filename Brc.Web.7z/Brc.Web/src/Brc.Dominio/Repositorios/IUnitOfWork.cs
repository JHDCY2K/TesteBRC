﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Brc.Dominio.Entidades;

namespace Brc.Dominio.Repositorios
{
    public interface IUnitOfWork
    {
        void SaveChanges();
    }
}