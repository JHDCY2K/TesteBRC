﻿using System;
using Microsoft.EntityFrameworkCore;
using Brc.Dominio.Entidades;

namespace Brc.Dados
{
    public class ContextoExemploBrc : DbContext
    {
        private readonly string _stringConexao;

		private DbContextOptions<ContextoExemploBrc> options;

        public DbSet<Usuario> Usuario { get; set; }
        public DbSet<Professor> Professor { get; set; }
        public DbSet<Aluno> Aluno { get; set; }


        public ContextoExemploBrc(string stringConexao)
        {
            if (string.IsNullOrWhiteSpace(stringConexao))
                throw new ArgumentNullException(nameof(stringConexao));

            _stringConexao = stringConexao;
        }

		public ContextoExemploBrc(DbContextOptions<ContextoExemploBrc> options)
        {
            this.options = options;
        }

		protected override void OnModelCreating(ModelBuilder builder)
        {
            #region ExemploWeb-metadado
            #endregion

            base.OnModelCreating(builder);
        }

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_stringConexao);
        }
    }
}