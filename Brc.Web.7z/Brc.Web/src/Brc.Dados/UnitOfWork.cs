﻿using System;
using Brc.Dominio.Repositorios;

namespace Brc.Dados
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ContextoExemploBrc _contexto;

        public UnitOfWork(ContextoExemploBrc contexto)
        {
            if (contexto == null)
                throw new ArgumentNullException(nameof(contexto));

            _contexto = contexto;
        }

        public void SaveChanges()
        {
            _contexto.SaveChanges();
        }
    }
}