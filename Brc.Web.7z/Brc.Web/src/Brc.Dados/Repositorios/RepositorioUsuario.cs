﻿using System.Linq;
using Brc.Dominio.Entidades;
using Brc.Dominio.Repositorios;

namespace Brc.Dados.Repositorios
{
    public class RepositorioUsuario : Repositorio<Usuario>, IRepositorioUsuario
    {

        public RepositorioUsuario(ContextoExemploBrc ContextoExemploBrc) : base(ContextoExemploBrc)
        {
        }

        public Usuario ObterPorLogin(string login)
        {
            return Contexto.Set<Usuario>()
                        .Where(p => p.Login == login )
                        .SingleOrDefault();
                        
        }

    }
}
