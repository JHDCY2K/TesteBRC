﻿using System.Linq;
using Brc.Dominio.Entidades;
using Brc.Dominio.Repositorios;

namespace Brc.Dados.Repositorios
{
    public class RepositorioCliente : Repositorio<Cliente>, IRepositorioCliente
    {
        public RepositorioCliente(ContextoExemploBrc contextoExemploWeb) : base(contextoExemploWeb)
        {
        }

        public Cliente ObterPorCPF(string cnpj)
        {
            return Contexto.Set<Cliente>()
                        .Where(p => p.CPF == cnpj)
                        .SingleOrDefault();

        }
    }
}
