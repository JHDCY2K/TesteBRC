﻿using System;
using System.Collections.Generic;
using System.Linq;
using Brc.Dominio.Entidades;
using Brc.Dominio.Repositorios;

namespace Brc.Dados.Repositorios
{
    public class RepositorioProfessor : Repositorio<Professor>, IRepositorioProfessor
    {
        public RepositorioProfessor(ContextoExemploBrc contextoExemploWeb) : base(contextoExemploWeb)
        {
        }

        public Professor ObterPorNome(string cnpj)
        {
            return Contexto.Set<Professor>()
                        .Where(p => p.Nome == cnpj)
                        .SingleOrDefault();

        }

        
    }
}
