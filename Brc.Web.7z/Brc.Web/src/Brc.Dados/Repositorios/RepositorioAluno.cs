﻿using System;
using System.Collections.Generic;
using System.Linq;
using Brc.Dominio.Entidades;
using Brc.Dominio.Repositorios;

namespace Brc.Dados.Repositorios
{
    public class RepositorioAluno : Repositorio<Aluno>, IRepositorioAluno
    {
        public RepositorioAluno(ContextoExemploBrc contextoExemploWeb) : base(contextoExemploWeb)
        {
        }

        public Aluno ObterPorNome(string nome)
        {
            return Contexto.Set<Aluno>()
                        .Where(p => p.Nome == nome)
                        .SingleOrDefault();

        }

        public IEnumerable<Aluno> ObterLista(int idade)
        {
            DateTime DataCorte = DateTime.Now.AddYears(-idade);

            return Contexto.Set<Aluno>()
                        .Where(p => p.DataNascimento < DataCorte);

        }

        public IEnumerable<Aluno> ObterListaProfessor(int id, int ini,int fim)
        {
            
            DateTime DataCorteIni = DateTime.Now.AddYears(-fim);
            DateTime DataCorteFim = DateTime.Now.AddYears(-ini);

            return Contexto.Set<Aluno>()
                        .Where(p => p.DataNascimento >= DataCorteIni && p.DataNascimento <= DataCorteFim);
                        

        }
    }
}
