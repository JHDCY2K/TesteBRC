﻿using System;

namespace Brc.Dtos
{
    public class AlunoLista
    {
        public long Id { get; set; }
        public string Nome { get; set; }
        public long IdProfessor { get; set; }
        public string NomeProfessor { get; set; }
        public DateTime DataNascimento { get; set; }
    }
}
