﻿using System;

namespace Brc.Dtos
{
    public class AgendaModel
    {
        public long IdCliente { get; set; }
        public DateTime DataAgenda { get; set; }

    }
}
