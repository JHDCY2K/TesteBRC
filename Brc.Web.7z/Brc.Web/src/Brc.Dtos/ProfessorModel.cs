﻿using System;

namespace Brc.Dtos
{
    public class ProfessorModel
    {
        public long Id { get; set; }
        public string Nome { get; set; }
    }
}
