﻿namespace Brc.Dtos
{
    public class LoginModel
    {
        public string Login { get; set; }
        public string Senha { get; set; }
    }
}