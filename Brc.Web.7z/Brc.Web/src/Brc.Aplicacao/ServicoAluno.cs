﻿using Brc.Dados.Repositorios;
using Brc.Dominio.Entidades;
using Brc.Dominio.Servicos;
using System;
using System.Collections.Generic;
using System.Text;

namespace Brc.Aplicacao
{
    public class ServicoAluno : IServicoAluno
    {
        private readonly IRepositorioAluno repositorioAluno;
        private readonly IServicoCriptografia servicoCriptografia;

        public ServicoAluno(IRepositorioAluno repositorioAluno, IServicoCriptografia servicoCriptografia)
        {
            this.repositorioAluno = repositorioAluno ?? throw new ArgumentNullException(nameof(repositorioAluno));
            this.servicoCriptografia = servicoCriptografia ?? throw new ArgumentNullException(nameof(servicoCriptografia));
        }

        public void Atualizar(Aluno aluno)
        {
            ValidaAluno(aluno);
            VerificarNomeExistente(aluno);            
            repositorioAluno.Alterar(aluno);
        }

        private void VerificarNomeExistente(Aluno aluno)
        {
            var alunoBase = repositorioAluno.ObterPorNome(aluno.Nome);
            if (alunoBase != null && aluno.Id != alunoBase.Id)
                throw new Exception("Aluno já existe na base de dados");
        }

        public void Inserir(Aluno aluno)
        {
            ValidaAluno(aluno);
            VerificarNomeExistente(aluno);
            repositorioAluno.Incluir(aluno);
        }

        public void Remover(Aluno aluno)
        {
            ValidaAluno(aluno);
            repositorioAluno.Excluir(aluno.Id);
        }

        private void ValidaAluno(Aluno aluno)
        {
            if (aluno == null)
                throw new NullReferenceException(nameof(aluno));
            if (aluno.Nome == null)
                throw new Exception("Nome inválido");
        }

        public IEnumerable<Aluno> ObterAlunos()
        {
            return repositorioAluno.ObterTodos();
        }

        public Aluno ObterPorId(long id)
        {
            return repositorioAluno.ObterPorId(id);
        }

        public IEnumerable<Aluno> ObterLista(int idade)
        {
            return repositorioAluno.ObterLista(idade);
        }


        public IEnumerable<Aluno> ObterListaProfessor(int id, int ini, int fim)
        {
            return repositorioAluno.ObterListaProfessor(id, ini, fim);
        }
    }
}
