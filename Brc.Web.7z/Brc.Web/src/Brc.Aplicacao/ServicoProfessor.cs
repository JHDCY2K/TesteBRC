﻿using Brc.Dados.Repositorios;
using Brc.Dominio.Entidades;
using Brc.Dominio.Servicos;
using System;
using System.Collections.Generic;
using System.Text;

namespace Brc.Aplicacao
{
    public class ServicoProfessor : IServicoProfessor
    {
        private readonly IRepositorioProfessor repositorioProfessor;
        private readonly IServicoCriptografia servicoCriptografia;

        public ServicoProfessor(IRepositorioProfessor repositorioProfessor, IServicoCriptografia servicoCriptografia)
        {
            this.repositorioProfessor = repositorioProfessor ?? throw new ArgumentNullException(nameof(repositorioProfessor));
            this.servicoCriptografia = servicoCriptografia ?? throw new ArgumentNullException(nameof(servicoCriptografia));
        }

        public void Atualizar(Professor professor)
        {
            ValidarProfessor(professor);
            VerificarNomeExistente(professor);            
            repositorioProfessor.Alterar(professor);
        }

        private void VerificarNomeExistente(Professor professor)
        {
            var professorBase = repositorioProfessor.ObterPorNome(professor.Nome);
            if (professorBase != null && professor.Id != professorBase.Id)
                throw new Exception("Professor já existe na base de dados");
        }

        public void Inserir(Professor professor)
        {
            ValidarProfessor(professor);
            VerificarNomeExistente(professor);
            repositorioProfessor.Incluir(professor);
        }

        public void Remover(Professor professor)
        {
            ValidarProfessor(professor);
            repositorioProfessor.Excluir(professor.Id);
        }

        private void ValidarProfessor(Professor professor)
        {
            if (professor == null)
                throw new NullReferenceException(nameof(professor));
            if ( professor.Nome == null)
                throw new Exception("Nome inválido");
        }

        public IEnumerable<Professor> ObterProfessores()
        {
            return repositorioProfessor.ObterTodos();
        }

        public Professor ObterPorId(long id)
        {
            return repositorioProfessor.ObterPorId(id);
        }

       

    }
}
